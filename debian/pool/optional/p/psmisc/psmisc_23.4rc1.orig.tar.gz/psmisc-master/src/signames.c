/*
 * signames.c: Dummy file to better generate signames.h
 */

#include <signal.h>
